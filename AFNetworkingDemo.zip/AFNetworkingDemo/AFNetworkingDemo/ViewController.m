//
//  ViewController.m
//  AFNetworkingDemo
//
//  Created by Riddhi on 03/10/13.
//  Copyright (c) 2013 bhavya. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"
#import "Reachability.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    /*
    NSURL *baseURL = [NSURL URLWithString:@"http://54.221.245.243/api/User/showArticleList"];
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:baseURL];
    
    NSOperationQueue *operationQueue = manager.operationQueue;
    [manager.reachabilityManager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusReachableViaWWAN:
            case AFNetworkReachabilityStatusReachableViaWiFi:
                [operationQueue setSuspended:NO];
                break;
            case AFNetworkReachabilityStatusNotReachable:
            default:
                [operationQueue setSuspended:YES];
                NSLog(@"Not reachable");
                break;
        }
    }];
     */
    
    /*
     
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        NSLog(@"Reachability: %@", AFStringFromNetworkReachabilityStatus(status));
    }];
    */
    
  /*
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];


    NSDictionary *parameters = @{@"UserId": @"24",@"NewsArticleId":@"0"};
    
    NSLog(@"%@",parameters);
    parameters = nil;
    
    manager.requestSerializer = [AFJSONRequestSerializer serializer];

    [manager POST:@"http://maps.google.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&sensor=false" parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject)
    {
        
        NSLog(@"JSON: %@", responseObject);
        //NSLog(@"Response: %@", [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);

        
    }failure:^(AFHTTPRequestOperation *operation, NSError *error)
    {
        NSLog(@"Error: %@", error);
    }];

    */
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    // if you want to sent parameters you can use above code
    manager.responseSerializer.acceptableContentTypes = [manager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
 // header("Content-Type: application/json");
//    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];

    
    [manager GET:@"your url" parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"responseObject %@",responseObject);
        
        NSString *jsonString =  [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        
        NSString *newJsonString = [jsonString stringByReplacingOccurrencesOfString:@"\\'" withString:@""];
        
        NSData *data = [newJsonString dataUsingEncoding:NSUTF8StringEncoding];
        
        NSError *error;
        NSArray *array = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
        
        NSLog(@"array %@",array);
        
        
        if (!array) {
            NSLog(@"Parsing JSON failed: %@", error);
        }
        
        /*
         NSData *newJSONData = [newJsonString dataUsingEncoding:NSUTF8StringEncoding];
         NSDictionary* json = [NSJSONSerialization
         JSONObjectWithData:newJSONData
         options:NSJSONReadingMutableContainers
         error:&error];
         NSLog(@"json %@",json);
        */
        
        NSLog(@"responseObject = %@", [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);

        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"%@",[error description]);
        
    }];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
