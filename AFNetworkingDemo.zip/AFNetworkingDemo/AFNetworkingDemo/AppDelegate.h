//
//  AppDelegate.h
//  AFNetworkingDemo
//
//  Created by Riddhi on 03/10/13.
//  Copyright (c) 2013 bhavya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
