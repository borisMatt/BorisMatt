//
//  SwipeTableViewController.h
//  SwipeTableCell
//
//  Created by Simon on 3/5/14.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SWTableViewCell.h"

@interface SwipeTableViewController : UITableViewController <SWTableViewCellDelegate>

@end
