//
//  ViewController.m
//  NSURLConnectionDemo
//
//  Created by bhavya on 1/8/14.
//  Copyright (c) 2014 Bhavya Kothari. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<NSURLConnectionDelegate>
- (IBAction)actionButtonCalled:(id)sender;

@end

@implementation ViewController{
    
    NSMutableData *_responseData;
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    /*
     
     NSString *basePath = [NSString stringWithFormat:@"http://ec2-54-242-57-85.compute-1.amazonaws.com/pharmaREP/Service1.svc/GetObstacleDetails?requestJSON={'TerritoryID':[%@],'UserName':'%@','Status':'%@'}",queryString,[prefs stringForKey:@"loggedUser"],statusForService];
     
     [db requestPath:basePath onCompletion:^(NSString *result, NSError *error){
     if (error || [result isEqualToString:@""]) {
     NSLog(@"Error in ObstacleList : %@",error);
     } else {
     
     NSData *data = [result dataUsingEncoding:NSUTF8StringEncoding];
     obstacleList =  [NSJSONSerialization JSONObjectWithData:data
     options:NSJSONReadingMutableLeaves|NSJSONReadingMutableContainers
     error:nil];
     NSLog(@"%@",@"ObstacleList complete");
     counterForSyncServiceSuccessful=counterForSyncServiceSuccessful+1;
     isObstacleList_page=YES;
     }
     counter=counter-1;
     NSLog(@"%d", counter);
     if(counter == 0)
     [self checkForAllServiceCalling];
     
     }];
     
     */
    
    /*
     NSString *urlString = [NSString stringWithFormat:@"https://hostname/DEMOService/DEMO.asmx/VerifyLogin?username=%@&password=%@&AuthenticationKey=%@",
     username,
     password,
     authenticationKey];
     NSURL *url = [NSURL URLWithString:urlString];
     NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url
     cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData
     timeoutInterval:10];
     */
    // Create the request.
    // GET REQUEST
    /*
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://maps.googleapis.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&sensor=true"]];
    
    // Create url connection and fire request
    NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    */
    
    // Send a synchronous request
    
    /*
    NSURLRequest * urlRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://maps.googleapis.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&sensor=true"]];
    
    NSURLResponse * response = nil;
    NSError * error = nil;
    NSData * data = [NSURLConnection sendSynchronousRequest:urlRequest
                                          returningResponse:&response
                                                      error:&error];
    
    if (error == nil)
    {
        // Parse data here
        NSError *error;
        NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
        NSLog(@"synchronous request DATA RESPONSE : %@", jsonDict);
    }
    */
    
    // request {"UserId":"44","NewsArticleId":"0","Date":""}
    
    // Create the request.
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://54.221.245.243/api/User/showArticleList"]];
    
    // Specify that it will be a POST request
    request.HTTPMethod = @"POST";
    //[request setHTTPMethod:@"POST"];

    // This is how we set header fields
    [request setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    
    
    // Convert your data and set your request's HTTPBody property
    
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"44",@"UserId",@"0",@"NewsArticleId",@"",@"Date", nil];
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];

    request.HTTPBody = jsonData;
    
    NSLog(@"request %@",request);
    
    // Create url connection and fire request
    NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - NSURLConnectionDelegate

 - (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
 // A response has been received, this is where we initialize the instance var you created
 // so that we can append data to it in the didReceiveData method
 // Furthermore, this method is called each time there is a redirect so reinitializing it
 // also serves to clear it
     
 _responseData = [[NSMutableData alloc] init];
 
 }
 
 - (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
 
     // Append the new data to the instance variable you declared
 
     [_responseData appendData:data];
 
 }
 
 - (NSCachedURLResponse *)connection:(NSURLConnection *)connection
 willCacheResponse:(NSCachedURLResponse*)cachedResponse
{
 
     // Return nil to indicate not necessary to store a cached response for this connection
 
     return nil;
 
 }
 
 - (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
 // The request is complete and data has been received
 // You can parse the stuff in your instance variable now
    
   // NSLog(@"_responseData %@",_responseData);
    
    NSError *error;
    NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:_responseData options:0 error:&error];
    
    NSLog(@"jsonDict %@",jsonDict);
    
    NSLog(@"jsonDict %d",[jsonDict count]);
    NSLog(@"jsonDict %d",[[jsonDict objectForKey:@"NewsArticleDetails"]count]);
    
}
 
 - (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{

    // The request has failed for some reason!
 // Check the error var

}
 

- (IBAction)actionButtonCalled:(id)sender
{

    NSLog(@"action Button Called");
    
}


@end
