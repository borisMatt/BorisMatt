//
//  ViewController.h
//  NSPredicateDemo
//
//  Created by Bhavya kothari on 5/21/14.
//  Copyright (c) 2014 Moweb Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
