//
//  main.m
//  NSPredicateDemo
//
//  Created by Bhavya kothari on 5/21/14.
//  Copyright (c) 2014 Moweb Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
