//
//  ViewController.m
//  NSPredicateDemo
//
//  Created by Bhavya kothari on 5/21/14.
//  Copyright (c) 2014 Moweb Technologies. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    // Enumerating Array
    
    NSArray *germanMakes = @[@"Mercedes-Benz", @"BMW", @"Porsche",
                             @"Opel", @"Volkswagen", @"Audi"];
    
    [germanMakes enumerateObjectsUsingBlock:^(id obj,
                                              NSUInteger idx,
                                              BOOL *stop) {
        NSLog(@"%ld: %@", (unsigned long)idx, obj);
    }];
    // Sub-Dividing Array

    NSArray *lastTwo = [germanMakes subarrayWithRange:NSMakeRange(4, 2)];
    NSLog(@"%@", lastTwo);    // Volkswagen, Audi
    
    
    // Comparing Two Arrays
    
    NSArray *sameGermanMakes = [NSArray arrayWithObjects:@"Mercedes-Benz",
                                @"BMW", @"Porsche", @"Opel",
                                @"Volkswagen", @"Audi", nil];
    
    if ([germanMakes isEqualToArray:sameGermanMakes]) {
        NSLog(@"Oh good, literal arrays are the same as NSArrays");
    }
    
    
    // BOOL checking
    if ([germanMakes containsObject:@"BMW"]) {
        NSLog(@"BMW is a German auto maker");
    }
    // Index checking
    NSUInteger index = [germanMakes indexOfObject:@"BMW"];
    if (index == NSNotFound) {
        NSLog(@"Well that's not quite right...");
    } else {
        NSLog(@"BMW is a German auto maker and is at index %ld", (unsigned long)index);
    }
    
    
    NSArray *sortedMakes = [germanMakes sortedArrayUsingComparator:
                            ^NSComparisonResult(id obj1, id obj2) {
                                if ([obj1 length] < [obj2 length]) {
                                    return NSOrderedAscending;
                                } else if ([obj1 length] > [obj2 length]) {
                                    return NSOrderedDescending;
                                } else {
                                    return NSOrderedSame;
                                }
                            }];
    NSLog(@"%@", sortedMakes);
    
    
    NSDictionary *car1 = @{
                           @"make": @"Volkswagen",
                           @"model": @"Golf",
                           @"price": [NSDecimalNumber decimalNumberWithString:@"18750.00"]
                           };
    NSDictionary *car2 = @{
                           @"make": @"Volkswagen",
                           @"model": @"Eos",
                           @"price": [NSDecimalNumber decimalNumberWithString:@"35820.00"]
                           };
    NSDictionary *car3 = @{
                           @"make": @"Volkswagen",
                           @"model": @"Jetta A5",
                           @"price": [NSDecimalNumber decimalNumberWithString:@"16675.00"]
                           };
    NSDictionary *car4 = @{
                           @"make": @"Volkswagen",
                           @"model": @"Jetta A4",
                           @"price": [NSDecimalNumber decimalNumberWithString:@"16675.00"]
                           };
    NSMutableArray *cars = [NSMutableArray arrayWithObjects:
                            car1, car2, car3, car4, nil];
    
    NSSortDescriptor *priceDescriptor = [NSSortDescriptor
                                         sortDescriptorWithKey:@"price"
                                         ascending:YES
                                         selector:@selector(compare:)];
    NSSortDescriptor *modelDescriptor = [NSSortDescriptor
                                         sortDescriptorWithKey:@"model"
                                         ascending:YES
                                         selector:@selector(caseInsensitiveCompare:)];
    
    NSArray *descriptors = @[priceDescriptor, modelDescriptor];
    [cars sortUsingDescriptors:descriptors];
    NSLog(@"%@", cars);    // car4, car3, car1, car2
    
    NSPredicate *beforeL = [NSPredicate predicateWithBlock:
                            ^BOOL(id evaluatedObject, NSDictionary *bindings) {
                                NSComparisonResult result = [@"L" compare:evaluatedObject];
                                if (result == NSOrderedDescending) {
                                    return YES;
                                } else {
                                    return NO;
                                }
                            }];
    NSArray *makesBeforeL = [germanMakes
                             filteredArrayUsingPredicate:beforeL];
    NSLog(@"%@", makesBeforeL);    // BMW, Audi
    
    
    
    NSArray *vanillaArray = @[ @"aa",
                              @"ba",
                              @"c",
                              @"aab",
                              @"aac"
                              ];
    
    NSPredicate *resultPredicate = [NSPredicate
                                    predicateWithFormat:@"SELF contains[cd] %@",
                                    @"aa"];
    
    NSArray *searchResults = [vanillaArray filteredArrayUsingPredicate:resultPredicate];
    
    NSLog(@"searchResults %@",searchResults);
    
    
    NSArray *arrayOfDictionary = @[
                              @{ // 0th element of array
        
        @"name":@"aa",
        @"surname":@"ba",
        @"lastName":@"c"
        
    },
                                
                                @{ // 1st element of array
                                    
                                    @"name":@"bb",
                                    @"surname":@"bb",
                                    @"lastName":@"c"
                                    
                                },
                              @{ // 0th element of array
                                  
                                  @"name":@"aaaa",
                                  @"surname":@"ba",
                                  @"lastName":@"c"
                                  
                                  },

                              ];
    
    NSString *predicateString = [NSString stringWithFormat:@"name CONTAINS[CD] '%@'",@"aa"];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:predicateString];
    
    NSArray *searchResults1 = [arrayOfDictionary filteredArrayUsingPredicate:predicate];
    
    NSLog(@"searchResults1 %@",searchResults1);
    
    NSArray *array = @[
                       @{@"co_user_id": @25,
                         @"curr_timpestamp": @"2013-10-09 16:57:39",
                         @"id": @82,
                         @"status": @0,
                         @"story_title": @"Second Story",
                         @"updated_time": @"2013-11-12 05:32:13",
                         @"user_id": @24
                         }
,
  @{@"co_user_id": @25,
                         @"curr_timpestamp": @"2013-10-09 16:57:39",
                         @"id": @81,
                         @"status": @0,
                         @"story_title": @"Second Story",
                         @"updated_time": @"2013-10-12 05:32:13",
                         @"user_id": @24
                         },
                       @{@"co_user_id": @25,
                         @"curr_timpestamp": @"2013-10-09 16:57:39",
                         @"id": @82,
                         @"status": @0,
                         @"story_title": @"Second Story",
                         @"updated_time": @"2013-10-12 05:32:13",
                         @"user_id": @24
                         },
                       @{@"co_user_id": @25,
                         @"curr_timpestamp": @"2013-10-09 16:57:39",
                         @"id": @82,
                         @"status": @0,
                         @"story_title": @"Second Story",
                         @"updated_time": @"2013-11-12 05:32:13",
                         @"user_id": @24
                         }
                       
                       ];
    
    // Create a basic date formatter to turn the strings into dates.
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    [formatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
    // Create the calendar for retrieving date components.
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    // Set the month being filtered
    NSInteger month = 10;
    // Filter for dictionaries whose 'updated_time's have the same value as 'month'.
    NSPredicate *predicateFinal = [NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, NSDictionary *bindings) {
        NSDate *date = [formatter dateFromString:evaluatedObject[@"updated_time"]];
        return [[calendar components:NSMonthCalendarUnit fromDate:date] month] == month;
    }];
    // Print the filtered array.
    NSLog(@"%@", [array filteredArrayUsingPredicate:predicateFinal]);


}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
